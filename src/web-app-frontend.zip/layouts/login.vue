<template>
	<RouterView />
</template>
